const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
let selectedPlatform = "auto";
let selectedQuality = "auto";
let historyItems = [];

function selectOne(selector, attr, value) {
  $$(selector).forEach(el => el.classList.toggle("selected", el.dataset[attr] === value));
}
$("#platforms").addEventListener("click", e => {
  const btn=e.target.closest("[data-platform]"); if(!btn)return;
  selectedPlatform=btn.dataset.platform; selectOne("[data-platform]","platform",selectedPlatform);
});
$("#qualities").addEventListener("click", e => {
  const btn=e.target.closest("[data-quality]"); if(!btn)return;
  selectedQuality=btn.dataset.quality; selectOne("[data-quality]","quality",selectedQuality);
});
$("#clearUrl").addEventListener("click",()=>{$("#videoUrl").value="";$("#notice").hidden=true;});
$("#analyzeBtn").addEventListener("click",()=>{
  const raw=$("#videoUrl").value.trim(), notice=$("#notice");
  const validUrl = /^https:\/\/\S+/i.test(raw);
  const hosts = {
    tiktok:["tiktok.com"], instagram:["instagram.com"],
    youtube:["youtube.com","youtu.be"], facebook:["facebook.com","fb.watch"]
  };
  const detected=Object.keys(hosts).find(p=>hosts[p].some(h=>raw.toLowerCase().includes(h)));
  let msg="";
  if(!raw) msg="يرجى لصق رابط الفيديو أولاً.";
  else if(!validUrl || !detected) msg="الرابط غير صالح أو المنصة غير مدعومة. استخدم رابط HTTPS صحيحاً.";
  else if(selectedPlatform!=="auto" && selectedPlatform!==detected) msg="الرابط لا يتطابق مع المنصة التي اخترتها.";
  else {
    msg=`تم التحقق من صيغة الرابط والتعرّف على ${detected}. هذه معاينة فقط؛ يلزم ربط خادم مرخّص لجلب بيانات الفيديو وجوداته وتنزيله.`;
    historyItems.unshift({platform:detected,url:raw,quality:selectedQuality,format:$("#audioOnly").checked?"MP3":$("#format").value.toUpperCase()});
    renderHistory();
  }
  notice.textContent=msg; notice.hidden=false;
});
function renderHistory(){
  const box=$("#historyList");
  if(!historyItems.length){box.innerHTML='<div class="empty-state"><span>◷</span><b>لا توجد عمليات بعد</b><p>ستظهر الروابط التي تفحصها هنا خلال هذه الجلسة.</p></div>';return;}
  box.innerHTML=historyItems.map(item=>`<div class="history-item"><b>${item.platform.toUpperCase()} · ${item.quality==="auto"?"Auto":item.quality==="original"?"Original":item.quality+"p"} · ${item.format}</b><small>${escapeHtml(item.url)}</small></div>`).join("");
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
$("#clearHistory").addEventListener("click",()=>{historyItems=[];renderHistory();});
function setTheme(light){document.body.classList.toggle("light",light);$("#themeSwitch").classList.toggle("on",!light);$("#themeToggle").textContent=light?"☾":"☼";}
$("#themeToggle").addEventListener("click",()=>setTheme(!document.body.classList.contains("light")));
$("#themeSwitch").addEventListener("click",()=>setTheme(!document.body.classList.contains("light")));
$$(".nav-tab").forEach(btn=>btn.addEventListener("click",()=>{
  $$(".nav-tab").forEach(x=>x.classList.toggle("active",x===btn));
  $$(".page").forEach(x=>x.classList.toggle("active",x.id===btn.dataset.page+"Page"));
}));
$("#audioOnly").addEventListener("change",e=>{if(e.target.checked)$("#format").value="mp3";});
